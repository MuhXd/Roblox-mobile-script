import asyncio
import websockets

async def websocket_client():
    # Replace '192.168.1.131' with the IP address of your WebSocket server
    uri = "ws://192.168.1.131:1000"
    async with websockets.connect(uri) as websocket:
        # Send a greeting message
        await websocket.send("Hello Server!")
        
        # Wait for a response and print it
        response = await websocket.recv()
        print(f"Received from server: {response}")

# Run the client
asyncio.run(websocket_client())
