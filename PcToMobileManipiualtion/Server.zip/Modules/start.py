import tkinter as tk
from tkinter import filedialog
import asyncio
import websockets
import socket
import tkinter as tk
import re
import idlelib.colorizer as ic
import idlelib.percolator as ip
from idlelib.colorizer import ColorDelegator
from idlelib.percolator import Percolator
# Store connected clients
connected_clients = set()

def get_local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # Connect to an external IP to get the local network interface IP
        s.connect(('8.8.8.8', 80))
        IP = s.getsockname()[0]
    except Exception:
        IP = '127.0.0.1'
    finally:
        s.close()
    return IP

async def echo(websocket, path):
    connected_clients.add(websocket)
    try:
        print("Client Connected")
        async for message in websocket:
            # Echo the message back to the client
            print(message)
    except websockets.exceptions.ConnectionClosed:
        print("Client disconnected")
    finally:
        connected_clients.remove(websocket)

import tkinter as tk
import threading


loop = asyncio.get_event_loop()
async def send_to_clients(message):
    if not message.strip():
        return  # Do not send empty messages
    # Send message to all connected clients
    if len(connected_clients) <= 0:
        print("No clients are connected")
    
    await asyncio.gather(*(client.send(message) for client in connected_clients))


def on_execute(message):
    asyncio.run_coroutine_threadsafe(send_to_clients(message), loop)

def open_file(textbox):
    file_path = filedialog.askopenfilename()
    if file_path:
        with open(file_path, 'r') as file:
            content = file.read()
            textbox.delete("1.0", tk.END)
            textbox.insert("1.0", content)


def highlight_lua_syntax(textbox):
    cdg = ColorDelegator()
    
    # Define the Lua keywords, operators, and comment syntax
    lua_keywords = r'\b(?P<KEYWORDS>and|break|do|else|elseif|end|false|for|function|if|in|local|nil|not|or|repeat|return|then|until|while)\b'
    MNumbers = r'\b(?P<MNumbers>\d+)\b' 
    morekeywords = r'\b(?P<Mkeywords>wait|warn|workspace|print)\b' 
    
    lua_pattern = '|'.join([lua_keywords, morekeywords, MNumbers])
    print("THIS WILL SHOW INFO THAT IS IMPORTANT")
    cdg = ic.ColorDelegator()
    cdg.prog = re.compile(lua_pattern + ic.make_pat().pattern, re.S)
    cdg.idprog = re.compile(r'\s+(\w+)', re.S)

    cdg.tagdefs['COMMENTS'] = {'foreground': '#7F7F7F', 'background': '#FFFFFF'}
    cdg.tagdefs['KEYWORDS'] = {'foreground': '#f24b4b', 'background': '#FFFFFF'}
    cdg.tagdefs['Mkeywords'] = {'foreground': '#00c8ff', 'background': '#FFFFFF'}
    cdg.tagdefs['MNumbers'] =  {'foreground': '#d1bd06', 'background': '#FFFFFF'}

    # These five lines are optional. If omitted, default colours are used.
    cdg.tagdefs['KEYWORD'] = {'foreground': '#007F00', 'background': '#FFFFFF'}
    cdg.tagdefs['BUILTIN'] = {'foreground': '#7F7F00', 'background': '#FFFFFF'}
    cdg.tagdefs['STRING'] = {'foreground': '#1e9606', 'background': '#FFFFFF'}
    cdg.tagdefs['DEFINITION'] = {'foreground': '#007F7F', 'background': '#FFFFFF'}

    ip.Percolator(textbox).insertfilter(cdg)


def loadex():
    Executor = tk.Tk()
    Executor.title("Funny lil executor")
    Executor.iconbitmap("./Textures/Icon.ico")
    
    textbox = tk.Text(Executor, height=12, width=100)
    textbox.pack()

    # Call the syntax highlighting function initially
    highlight_lua_syntax(textbox)
    button = tk.Button(Executor, text="Execute", command=lambda: on_execute(textbox.get("1.0", tk.END)))
    button.pack(side=tk.LEFT)
   
    button_open = tk.Button(Executor, text="Open File", command=lambda: on_execute(open_file(textbox)))
    button_open.pack(side=tk.LEFT)

    Executor.mainloop()

    
async def main():
    local_ip = get_local_ip()
    port = 1000  # Replace with your desired port
    server = await websockets.serve(echo, local_ip, port)
    print(f"{local_ip} (Server) started on port {port}")
    print(f"Put this Above the loadstring as this is the hook ip\n_G.PCHOOKIP = '{local_ip}' ")
    await server.wait_closed()


def start_loop():
    asyncio.set_event_loop(loop)
    loop.run_forever()


loop_thread = threading.Thread(target=start_loop)
loop_thread.start()
# Start the event loop and run the tasks concurrently
input_thread = threading.Thread(target=loadex)
input_thread.start()

asyncio.run(main())
